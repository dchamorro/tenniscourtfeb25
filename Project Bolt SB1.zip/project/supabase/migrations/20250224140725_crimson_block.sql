/*
  # Create courts and reservations tables

  1. New Tables
    - `courts`
      - `id` (uuid, primary key)
      - `name` (text) - Court name
      - `surface` (text) - Court surface type
      - `image_url` (text) - URL to court image
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `reservations`
      - `id` (uuid, primary key)
      - `court_id` (uuid) - References courts
      - `user_id` (uuid) - References profiles
      - `start_time` (timestamp)
      - `end_time` (timestamp)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for:
      - Public read access to courts
      - Authenticated users can create reservations
      - Users can read and cancel their own reservations
*/

CREATE TABLE IF NOT EXISTS courts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  surface text NOT NULL,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  court_id uuid REFERENCES courts(id) NOT NULL,
  user_id uuid REFERENCES profiles(id) NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT no_overlapping_reservations EXCLUDE USING gist (
    court_id WITH =,
    tstzrange(start_time, end_time) WITH &&
  )
);

ALTER TABLE courts ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;

-- Courts policies
CREATE POLICY "Courts are viewable by everyone"
  ON courts
  FOR SELECT
  TO public
  USING (true);

-- Reservations policies
CREATE POLICY "Users can create reservations"
  ON reservations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their reservations"
  ON reservations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can cancel their reservations"
  ON reservations
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert sample courts
INSERT INTO courts (name, surface, image_url) VALUES
  ('Court 1', 'Hard Court', 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000'),
  ('Court 2', 'Clay Court', 'https://images.unsplash.com/photo-1622163642998-1ea32e539c1e?q=80&w=1000'),
  ('Court 3', 'Hard Court', 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000');