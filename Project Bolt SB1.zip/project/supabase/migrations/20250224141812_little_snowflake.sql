/*
  # Create courts and reservations tables

  1. New Tables
    - `courts`
      - `id` (uuid, primary key)
      - `name` (text) - Court name
      - `surface` (text) - Court surface type
      - `image_url` (text) - URL to court image
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `reservations`
      - `id` (uuid, primary key)
      - `court_id` (uuid) - References courts
      - `user_id` (uuid) - References profiles
      - `start_time` (timestamp)
      - `end_time` (timestamp)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for:
      - Public read access to courts
      - Authenticated users can create reservations
      - Users can read and cancel their own reservations

  3. Constraints
    - Prevent overlapping reservations using a function-based approach
*/

-- Create courts table
CREATE TABLE IF NOT EXISTS courts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  surface text NOT NULL,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reservations table
CREATE TABLE IF NOT EXISTS reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  court_id uuid REFERENCES courts(id) NOT NULL,
  user_id uuid REFERENCES profiles(id) NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_reservation_time CHECK (end_time > start_time)
);

-- Create function to check for overlapping reservations
CREATE OR REPLACE FUNCTION check_reservation_overlap()
RETURNS trigger AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM reservations
    WHERE court_id = NEW.court_id
    AND id != NEW.id
    AND (
      (NEW.start_time, NEW.end_time) OVERLAPS (start_time, end_time)
    )
  ) THEN
    RAISE EXCEPTION 'Reservation overlaps with existing booking';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to prevent overlapping reservations
CREATE TRIGGER prevent_reservation_overlap
  BEFORE INSERT OR UPDATE ON reservations
  FOR EACH ROW
  EXECUTE FUNCTION check_reservation_overlap();

-- Enable Row Level Security
ALTER TABLE courts ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;

-- Courts policies
CREATE POLICY "Courts are viewable by everyone"
  ON courts
  FOR SELECT
  TO public
  USING (true);

-- Reservations policies
CREATE POLICY "Users can create reservations"
  ON reservations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their reservations"
  ON reservations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can cancel their reservations"
  ON reservations
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert sample courts
INSERT INTO courts (name, surface, image_url) VALUES
  ('Court 1', 'Hard Court', 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000'),
  ('Court 2', 'Clay Court', 'https://images.unsplash.com/photo-1622163642998-1ea32e539c1e?q=80&w=1000'),
  ('Court 3', 'Hard Court', 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000');