import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import CalendarStrip from 'react-native-calendar-strip';
import { format } from 'date-fns';
import { useRouter } from 'expo-router';

const COURTS = [
  {
    id: 1,
    name: 'Court 1',
    surface: 'Hard Court',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000',
  },
  {
    id: 2,
    name: 'Court 2',
    surface: 'Clay Court',
    image: 'https://images.unsplash.com/photo-1622163642998-1ea32e539c1e?q=80&w=1000',
  },
  {
    id: 3,
    name: 'Court 3',
    surface: 'Hard Court',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000',
  },
];

const TIME_SLOTS = [
  '08:00', '09:00', '10:00', '11:00', '12:00',
  '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00',
];

export default function CourtsScreen() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const router = useRouter();

  const handleReservation = (courtId: number, time: string) => {
    // Handle reservation logic
    console.log(`Reserving court ${courtId} at ${time}`);
  };

  return (
    <View style={styles.container}>
      <CalendarStrip
        style={styles.calendar}
        calendarHeaderStyle={styles.calendarHeader}
        dateNumberStyle={styles.calendarDateNumber}
        dateNameStyle={styles.calendarDateName}
        highlightDateNumberStyle={styles.calendarHighlightDate}
        highlightDateNameStyle={styles.calendarHighlightDate}
        onDateSelected={setSelectedDate}
      />

      <ScrollView style={styles.courtsContainer}>
        {COURTS.map((court) => (
          <View key={court.id} style={styles.courtCard}>
            <Image source={{ uri: court.image }} style={styles.courtImage} />
            <View style={styles.courtInfo}>
              <Text style={styles.courtName}>{court.name}</Text>
              <Text style={styles.courtSurface}>{court.surface}</Text>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.timeSlots}>
              {TIME_SLOTS.map((time) => (
                <TouchableOpacity
                  key={time}
                  style={styles.timeSlot}
                  onPress={() => handleReservation(court.id, time)}>
                  <Text style={styles.timeText}>{time}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  calendar: {
    height: 100,
    paddingTop: 20,
    paddingBottom: 10,
  },
  calendarHeader: {
    color: '#0f172a',
  },
  calendarDateNumber: {
    color: '#64748b',
  },
  calendarDateName: {
    color: '#64748b',
  },
  calendarHighlightDate: {
    color: '#2563eb',
  },
  courtsContainer: {
    padding: 16,
  },
  courtCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  courtImage: {
    width: '100%',
    height: 150,
  },
  courtInfo: {
    padding: 16,
  },
  courtName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  courtSurface: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  timeSlots: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  timeSlot: {
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 8,
  },
  timeText: {
    color: '#0f172a',
    fontSize: 14,
  },
});