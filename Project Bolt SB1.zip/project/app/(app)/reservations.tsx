import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';

const RESERVATIONS = [
  {
    id: '1',
    courtName: 'Court 1',
    date: new Date(2024, 1, 15, 10, 0),
    duration: 60,
    surface: 'Hard Court',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1000',
  },
  {
    id: '2',
    courtName: 'Court 2',
    date: new Date(2024, 1, 16, 14, 0),
    duration: 60,
    surface: 'Clay Court',
    image: 'https://images.unsplash.com/photo-1622163642998-1ea32e539c1e?q=80&w=1000',
  },
];

export default function ReservationsScreen() {
  const handleCancelReservation = (id: string) => {
    // Handle cancellation logic
    console.log(`Cancelling reservation ${id}`);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Reservations</Text>
      </View>
      
      {RESERVATIONS.map((reservation) => (
        <View key={reservation.id} style={styles.reservationCard}>
          <Image source={{ uri: reservation.image }} style={styles.courtImage} />
          <View style={styles.reservationInfo}>
            <Text style={styles.courtName}>{reservation.courtName}</Text>
            <Text style={styles.date}>
              {format(reservation.date, 'MMMM d, yyyy')}
            </Text>
            <Text style={styles.time}>
              {format(reservation.date, 'h:mm a')} - {format(new Date(reservation.date.getTime() + reservation.duration * 60000), 'h:mm a')}
            </Text>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => handleCancelReservation(reservation.id)}>
              <Ionicons name="close-circle-outline" size={20} color="#ef4444" />
              <Text style={styles.cancelText}>Cancel Reservation</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  reservationCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    margin: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  courtImage: {
    width: '100%',
    height: 150,
  },
  reservationInfo: {
    padding: 16,
  },
  courtName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  date: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 4,
  },
  time: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 12,
  },
  cancelButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fef2f2',
    padding: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  cancelText: {
    color: '#ef4444',
    marginLeft: 4,
    fontWeight: '500',
  },
});